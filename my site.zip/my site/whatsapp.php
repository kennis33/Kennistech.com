<?php

// Update the path below to your autoload.php,
// see https://getcomposer.org/doc/01-basic-usage.md
require_once '/path/to/vendor/autoload.php';

use Twilio\Rest\Client;

// Find your Account SID and Auth Token at twilio.com/console
// and set the environment variables. See http://twil.io/secure
$sid = getenv("TWILIO_ACCOUNT_SID");
$token = getenv("TWILIO_AUTH_TOKEN");
$twilio = new Client($sid, $token);

$message = $twilio->messages
                  ->create("whatsapp:+15005550006", // to
                           [
                               "from" => "whatsapp:+14155238886",
                               "body" => "Hello there!"
                           ]
                  );

print($message->sid);


?>


<?php

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://api.wassenger.com/v1/messages",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => "{\"phone\":\"+1234567890\",\"message\":\"Hello world! This is a test message\"}",
  CURLOPT_HTTPHEADER => array(
    "token: <api key>"
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  echo $response;
}
?>





curl -i -X POST `
  https://graph.facebook.com/v15.0/106221145677789/messages `
  -H 'Authorization: Bearer EAAMkxQreFjUBALpkYrnSdiG5g5ZC4NJAB2kbRZAo7TTkNdSNgqWc2dvN8wzGZCEfq2Ss3lvzZB43zDDfcAidmqMMN07djYYuZCpCjkDIpeY7aMgyxpNMWlORJUgKNZC4pBHWZCtWtR5oZASgG4oB3E0nxiS7SzcUZBPHfg4uBsbgOuRTy0r6VhcooNyKRcO15yrZA4yzx51xRrUAZDZD' `
  -H 'Content-Type: application/json' `
  -d '{ \"messaging_product\": \"whatsapp\", \"to\": \"2347032783760\", \"type\": \"template\", \"template\": { \"name\": \"hello_world\", \"language\": { \"code\": \"en_US\" } } }'


